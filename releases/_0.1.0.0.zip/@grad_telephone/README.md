Telephone Functionality in Arma (heavy WIP)

* requires TFAR + CBA
* will support vanilla phone booths + GM phone booths
* will support rotary and digit number phones
* connection is always A <-> B and mono-ear
* phones trying to connect to an existing connection will receive occupied signal
* easily add phone functionality to any object
* phone numbers are auto generated
